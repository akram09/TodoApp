package oxxy.kero.roiaculte.team7.domain;

public class MyClass {
}
